<template src="./template.html"></template>
<script src="./script.js"></script>
<style lang="less" src="./style.less"></style>
