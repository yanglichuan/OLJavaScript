<template>
  <div>这是home组件</div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
// 样式只会在当前组件生效
div {
  background-color: red;
}
</style>
