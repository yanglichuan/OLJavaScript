/*
Navicat MySQL Data Transfer

Source Server         : 本机
Source Server Version : 50718
Source Host           : localhost:3306
Source Database       : wx69

Target Server Type    : MYSQL
Target Server Version : 50718
File Encoding         : 65001

Date: 2018-12-13 18:05:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for material
-- ----------------------------
DROP TABLE IF EXISTS `material`;
CREATE TABLE `material` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `realpath` varchar(255) NOT NULL DEFAULT '' COMMENT '上传成功的地址',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `is_forever` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0临时 1永久',
  `media_id` varchar(255) NOT NULL DEFAULT '' COMMENT '媒体ID',
  `type` enum('image','voice') NOT NULL DEFAULT 'image' COMMENT '素材类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='素材管理表';

-- ----------------------------
-- Records of material
-- ----------------------------
INSERT INTO `material` VALUES ('5', 'F:\\www\\class\\web69\\wx.com/up/1544690636.jpg', '1544690638', '0', 'aL_s97N3iRc8b30WkrANK9d5cl2tVO_MSr64o1kXqH8Jq0iDmgjpOLAc4Mbr4tIg', 'image');
INSERT INTO `material` VALUES ('7', 'F:\\www\\class\\web69\\wx.com/up/1544691324.jpg', '1544691326', '0', 'ZXLB2TLGAcJhUSeYAIe4C_zp01YuwyL0_6ynnq_lFXqwPFaAek0mq4bYNhpJGX96', 'image');
INSERT INTO `material` VALUES ('8', 'F:\\www\\class\\web69\\wx.com/up/1544691343.jpg', '1544691344', '1', 'T4fyJ7hV_NJFEfiMWFwg1UZ50YiuLcWrSm6W84jjGJ0', 'image');
