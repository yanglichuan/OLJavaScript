<?php
/**
 * 主动模式
 */
/*$wx = new Wechat();
$menuList = include './menu.php';
# 删除菜单
echo $wx->delMenu();
# 创建菜单
echo $wx->createMenu($menuList);*/

class Wechat {
	// appid
	const APPID = 'wx3e7552f91168c93f';
	// appsecret
	const SECRET = 'c672118b3988b288492abfc0eb074f55';

	/**
	 * 得到access_token  access_token是全局唯一有效的
	 * @return [type] [description]
	 */
	private function getAccessToken(){
		# 缓存的文件
		$cacheFile = self::APPID.'_cache.log';

		// 判断文件是否存在，要是不存在则表示没有缓存
		// 存在判断修改的时间是否过了有效期，如果没有过，则不进行url网络请求
		if (is_file($cacheFile) && filemtime($cacheFile)+7000 > time()) {
			echo '缓存了<hr>';
			return file_get_contents($cacheFile);
		}

		// 第1次或缓存过期
		$surl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s';
		$url = sprintf($surl,self::APPID,self::SECRET);
		// 发起GET请求
		$json = $this->http_request($url);
		// 把json转为数组
		$arr = json_decode($json,true);
		$access_token = $arr['access_token'];
		// 写缓存
		file_put_contents($cacheFile,$access_token);
		// 返回数据
		echo '2222<hr>';
		return $access_token;
	}

	/**
	 * 缓存到memcache中
	 * @return [type] [description]
	 */
	private function getAccessTokenMem(){
		# 缓存的key值
		$cachekey = self::APPID.'_key';
		$mem = new Memcache();
		$mem->addServer('localhost',11211);
		// 添加 如果存在则返回false
		#$mem->add('b','bbb',0,3);
		#$mem->set('d','ddd',0,5);
		# 有缓存 读缓存
		if (false != ($access_token = $mem->get($cachekey))) {
			return $access_token;
		}
		// 第1次或缓存过期
		$surl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s';
		$url = sprintf($surl,self::APPID,self::SECRET);
		// 发起GET请求
		$json = $this->http_request($url);
		// 把json转为数组
		$arr = json_decode($json,true);
		$access_token = $arr['access_token'];
		// 写缓存
		$mem->set($cachekey,$access_token,0,7000);
		// 返回数据
		return $access_token;
	}

	/**
	 * 创建自定义菜单
	 * @param  array|string $menu [description]
	 * @return [type]       [description]
	 */
	public function createMenu($menu){
		if(is_array($menu)){
			// 因为菜单有中文，所以一定要写json_encode第2个参数，让中文不乱码
			$data = json_encode($menu,JSON_UNESCAPED_UNICODE); # 256
		}else{
			$data = $menu;
		}
		// 创建自定义菜单URL
		$url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$this->getAccessTokenMem();
		// 发起请求
		$json = $this->http_request($url,$data);
		return $json;
	}

	/**
	 * 删除自定义菜单
	 * @return [type] [description]
	 */
	public function delMenu(){
		$url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$this->getAccessTokenMem();
		// 发起请求
		$json = $this->http_request($url);
		return $json;
	}

	// 上传素材
	public function uploadMaterial(string $path,string $type='image',$is_forever=0){
		if ($is_forever == 0) {
			// 临时
			$surl = 'https://api.weixin.qq.com/cgi-bin/media/upload?access_token=%s&type=%s';
		}else{
			// 永久
			$surl = 'https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=%s&type=%s';
		}

		$url = sprintf($surl,$this->getAccessTokenMem(),$type);
		// 上传素材到微信公众平台
		$json = $this->http_request($url,[],$path);
		// json转为数组
		$arr = json_decode($json,true);
		// 有前返回，没有则返回空 php7提供的null合并
		return $arr['media_id'] ?? '';
	}

	/**
	 * 发送客服消息
	 * @param  [type] $openid [description]
	 * @param  [type] $msg    [description]
	 * @return [type]         [description]
	 */
	public function kefuMsg($openid,$msg){
		$url = 'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.$this->getAccessTokenMem();
		$data = '{
			"touser":"'.$openid.'",
			"msgtype":"text",
			"text":
			{
				"content":"'.$msg.'"
			}
		}';
		$json = $this->http_request($url,$data);
		return $json;
	}




	/**
	 * 发起请求
	 * @param  strin $url  url地址
	 * @param  string|array $ret  请求体
	 * @param  string $file 上传的文件绝对地址
	 * @return [type]       [description]
	 */
	private function http_request($url,$ret='',$file=''){
		if (!empty($file)) {  // 有文件上传
			# php5.5之前 '@'.$file;就可以进地文件上传
			# $ret['pic'] = '@'.$file;
			# php5.6之后用此方法
			$ret['media'] = new CURLFile($file);
		}
		// 初始化
		$ch = curl_init();
		// 相关设置
		# 设置请求的URL地址
		curl_setopt($ch,CURLOPT_URL,$url);
		# 请求头关闭
		curl_setopt($ch,CURLOPT_HEADER,0);
		# 请求的得到的结果不直接输出，而是以字符串结果返回  必写
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		# 设置请求的超时时间 单位秒
		curl_setopt($ch,CURLOPT_TIMEOUT,30);
		# 设置浏览器型号
		curl_setopt($ch,CURLOPT_USERAGENT,'MSIE001');

		# 证书不检查
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);

		# 设置为post请求
		if($ret){ # 如果 $ret不为假则是post提交
			# 开启post请求
			curl_setopt($ch,CURLOPT_POST,1);
			# post请求的数据 
			curl_setopt($ch,CURLOPT_POSTFIELDS,$ret);
		}
		// 发起请求
		$data = curl_exec($ch);
		// 有没有发生异常
		if(curl_errno($ch) > 0){
			// 把错误发送给客户端
			echo curl_error($ch);
			$data = '';
		}
		// 关闭请求
		curl_close($ch);
		return $data;
	}

}

