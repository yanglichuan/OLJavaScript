<?php

echo time().PHP_EOL;