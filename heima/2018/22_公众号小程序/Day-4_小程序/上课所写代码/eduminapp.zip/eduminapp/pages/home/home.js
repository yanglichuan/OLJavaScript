// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    age:20
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad (options) {
    console.log(this.data.age);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log(this.data.age);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 同步
    this.data.age = 30;
    // 异步
    setTimeout(() => {
      // 把控制层中的数据，发送到视图层
      this.setData({
        age:this.data.age
      })
    }, 2000);
    

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log(this.data.age)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log('下拉了');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('上拉了');
  },

  onShareAppMessage() {
    return {
      title: '小明你好',
      path: '/pages/index/index',
      imageUrl: 'url',
      success: res => {},
      fail: () => {},
      complete: () => {}
    };
  }
  
})