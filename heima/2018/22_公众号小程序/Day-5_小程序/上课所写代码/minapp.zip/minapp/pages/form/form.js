// pages/form/form.js
Page({

  data: {
    sec:3,
    timer:null
  },
  onLoad: function (options) {

  },

  // 表单接受事件
  postFun(evt){
    console.log(evt.detail.value);
  },

  sendFun(evt){
    var n = this.data.sec
    this.data.timer = setInterval(()=>{
      n--;
      if(n == 0) clearInterval(this.data.timer);
      this.setData({
        sec:n
      })
    },1000);
  }

  
})