// pages/input/input.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    lists: ["aaaaa", "aabbbaa", "bbbcccbb"],
    items: [],
    timer: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {},

  // 搜索
  searchFun(evt) {
    let kw = evt.detail.value;

    /*  let index = 'bbbbb'.indexOf('a');
    console.log(index); */

    /* let bool = new RegExp(kw,'ig').test('aaaaa');
    console.log(bool); */
    let items = [];

    clearTimeout(this.data.timer);
    this.data.timer = setTimeout(() => {
      this.data.lists.forEach((item, index) => {
        if (new RegExp(kw, "ig").test(item)) {
          items.push(item);
        }
      });
      this.setData({
        items
      });
    }, 3000);
  }
});
