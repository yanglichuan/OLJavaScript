// pages/video/video.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 获取播放时间
  updatetimeFun(evt){
    let n = Math.floor(evt.detail.currentTime);
    if(3 == n){
      console.log('记录一下此用户');
    }
  }
  
})