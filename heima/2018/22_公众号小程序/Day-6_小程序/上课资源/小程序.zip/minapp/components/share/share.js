// components/share/share.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // Number String boolean  Array object null
    //share:Number
    share: {
      type: Number,
      value: 10
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    age: 10
  },

  created(){
    console.log('created')
  },
  /**
   * 组件的方法列表
   */
  methods: {
    abc(evt){
      console.log(this.properties.share);
      console.log(evt);
    }
  }
});
