import MyCache from "../../utils/MyCache.js";
let cache = new MyCache();

Page({
  data: {},

  onLoad(options) {
    this._cache();
  },

  _cache() {
    // 设置缓存
    // 异步
    /* wx.setStorage({
      key: 'data1',
      data: '张三',
      success: (result)=>{
        console.log(result);
      },
      fail: ()=>{},
      complete: ()=>{}
    }); */
    // 同步
    // 没有返回
    //wx.setStorageSync('data2', '李四');

    // 获取
    // 异步
    /* wx.getStorage({
      key: 'data2',
      success: (result)=>{
        console.log(result);
      },
      fail: ()=>{},
      complete: ()=>{}
    }); */
    // 同步
    /* let data2 = wx.getStorageSync('data2') || '333';
    console.log(data2); */

    // 删除
    //wx.removeStorageSync('data1');

    // 清除所有
    //wx.clearStorageSync();

    cache.set({
      key: "name",
      data: "张三",
      expire: new Date().getTime() + 500
    });
    console.log(cache.get('name'));
  }
});
