// pages/evt/evt.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 开始时间
    stime: 0,
    // 结束时间
    etime: 0,
    // 定义一个默认颜色
    color:"#000"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {},

  clickFun(evt) {
    // 查看方法的参数列表
    //console.log(arguments);

    console.log(evt);

    console.log(11111);
  },
  subClickFun() {
    console.log(2222);
  },

  clickFun2(evt){
    // let name = evt.currentTarget.dataset.name;
    // es6 解构赋值
    // 申明与赋值必须在一行
    // 右边是什么结构，左边就是什么结构
    // 如果是对象，则名称要一致,数组名称可以随便起
    let {name} = evt.currentTarget.dataset;
    //let [{id,name},a,b]  = [{id:1,name:'李四王五'},1,2];


    console.log(typeof name);
  },

  // 点击开始事件
  stimeFun() {
    let stime = new Date().getTime();
    // 同步改变值
    this.data.stime = stime;
  },
  // 点击结束事件
  etimeFun() {
    let etime = new Date().getTime();
    this.data.etime = etime;
    // 得到了点击的时间
    let diff = etime - this.data.stime;
    let color = this.retColor(diff);
    // 把结果发送到视图层
    /* this.setData({
      color:color
    }) */
    // es6中，如果json对象中key和value变量是一样的，可以不写value变量名
    this.setData({
      color
    })
  },
  retColor(num) {
    //let n = Math.floor(num/1000);
    let color = '#000';
    if(num <= 1000){
      color = '#ff0000';
    }else if(num <= 2000){
      color = '#00ff00';
    }else if(num == 6000){
      color = '#0000ff';
    }else{
      color = '#ccc';
    }
    return color;
  }
});
