// 请求的父类  export default
import Http from "../../utils/Http.js";
// 导入配置文件 export 直接导出的
import {Config} from '../../utils/Config.js';
// 继承
class UserModel extends Http{

    // 用户列表
    getUsers({data={}}){
        let url = Config.usersUrl;
        return this.http_req({url,data});
    }
}
// 导出
export default UserModel;