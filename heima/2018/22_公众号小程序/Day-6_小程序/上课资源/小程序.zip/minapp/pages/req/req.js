// 导入
//const obj = require('../../utils/tools.js');
// es6导入
//import { http_req6, http_req } from "../../utils/tools.js";

/* import Http from "../../utils/Http.js";
let http = new Http(); */

// 类似于我们php中的use导入
import UserModel from "./model.js";
// 因为是类，所以我们要new实例化一下
let model = new UserModel();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    items: [],
    offset: 0,
    limit: 20
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    /* wx.request({
      url: 'http://www.aaa.com/api/users',
      data: {},
      header: {'content-type':'application/json'},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      // 请求成功时返回的回调
      success: (result)=>{
        // 返回布尔值，表示参数字符串是否在原字符串的头部
        let str = result.statusCode+'';
        console.log(str.startsWith(2));
        console.log(result.statusCode<300 && result.statusCode>=200);
        console.log(result.data);
      },
      // 断网、服务器挂掉、请求超时时触发的回调
      fail: ()=>{
        console.log('发生了异常情况');
      },
      // 请求不管是否成功都完触发，此次操作完成时触发
      complete: ()=>{}
    }); */

    // 用户请求
    /* this._http_req(
      "http://www.aaa.com/api/v1/users",
      { offset: 0, limit: 2 },
      ret => {
        console.log(ret.data.data);
      },
      () => {}
    ); */

    /* this._http_req2({
      url:'http://www.aaa.com/api/v1/users',
      data:{offset:0,limit:2},
      scb:function(ret){
        console.log(ret.data.data);
      },
      fcb:function(){
      }
    }); */

    /* this._http_req3({
      url: "http://www.aaa.com/api/v1/users",
      data: { offset: 0, limit: 20 },
      scb: ret => {
        this.setData({
          items: ret.data.data
        });
      },
      fcb() {}
    }); */

    /* obj.http_req6({
      url:'http://www.aaa.com/api/v1/users',
      data:{offset:0,limit:20},
      scb:ret=>{
        console.log(ret);
      },
      fcb(){
      }
    }) */
    /* http_req6({
      url:'http://www.aaa.com/api/v1/users',
      data:{offset:0,limit:2},
      scb:ret=>{
        console.log(ret);
      },
      fcb(){
      }
    }) */

    /* let pro = http_req({
      url:'http://www.aaa.com/api/v1/users',
      data:{offset:0,limit:2}
    }).then(ret=>{
      console.log(ret);
    },err=>{

    }) */

    /* http.http_req({
      url: "http://www.aaa.com/api/v1/users",
      data: { offset: 0, limit: 2 }
    }).then(ret=>{
      console.log(ret);
    }) */

    // 初始化数据
    model
      .getUsers({
        data: { offset: this.data.offset, limit: this.data.limit }
      })
      .then(ret => {
        this.setData({
          items: ret.data.data,
          // 改变获取数据位置
          offset: this.data.offset + ret.data.data.length
        });
      });
  },
  // 加载更多
  getmore(evt) {
    model
      .getUsers({
        data: { offset: this.data.offset, limit: this.data.limit }
      })
      .then(ret => {
        this.setData({
          // 合并数组
          items: this.data.items.concat(ret.data.data),
          // 改变获取数据位置
          offset: this.data.offset + ret.data.data.length
        });
      });
  },
  // 发送网络请求
  _http_req(url = "", data = {}, scb, fcb) {
    // 用户列表
    wx.request({
      url,
      data,
      success: ret => {
        scb(ret);
      },
      fail: () => {
        fcb("失败了");
      }
    });
  },
  // url = "", data = {}, scb, fcb
  _http_req2(params) {
    // 用户列表
    wx.request({
      url: params.url,
      data: params.data,
      success: ret => {
        params.scb(ret);
      },
      fail: () => {
        params.fcb("失败了");
      }
    });
  },
  //es6 参数  解构赋值   前期一个最终方案
  _http_req3({ url = "", data = {}, scb, fcb }) {
    // 用户列表
    wx.request({
      url,
      data,
      success: ret => {
        scb(ret);
      },
      fail: () => {
        fcb("失败了");
      }
    });
  }
});
