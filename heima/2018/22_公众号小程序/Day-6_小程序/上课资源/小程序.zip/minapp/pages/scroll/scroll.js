// pages/scroll/scroll.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    style:'',
    top:0,
    lists:[
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据1',
      '我就是数据2'
    ],
    items:[
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2',
      '数据2'
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad (options) {
    console.log(options);

  },

  getmore(evt){
    console.log('到底了')
    /* this.data.items.forEach((item,index)=>{
      this.data.lists.push(item);
    }) */
    let lists = this.data.lists.concat(this.data.items);
    this.setData({
      lists
    })
  },
  top(evt){
    // 滚动离顶部高度
    let scrollTop = evt.detail.scrollTop;

    // 显示回到顶部
    if(scrollTop >= 150){
      this.setData({
        style:'now'
      })
    }
    // 隐藏回到顶部
    if(scrollTop < 150){
      this.setData({
        style:''
      })
    }

  },
  // 回到顶部
  gotoTop(){
    this.setData({
      top:0
    })
  }

})