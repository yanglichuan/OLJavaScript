Page({
  data: {},
  onLoad(options) {
    this._alert();
  },

  _alert() {
    // 加载框
    /* wx.showLoading({
      // 标题 7个字
      title: "小钟还是比较帅",
      // 透明蒙层 true有蒙层  false没有蒙层   默认为true
      mask: false
    }); */

    // 提示框
    /* wx.showToast({
      // 标题 7个汉字 [有图标就是7个汉字]
      title: '小钟还是比较帅小钟还是比较帅',
      // 默认图标 success loading none
      icon: 'success',
      // 图片，它的优先级大于icon，image设置值则 icon失效  自定义图标的本地路径
      image: '/images/icon.png',
      // 提示框时长 毫秒
      duration: 60000,
      // 透明蒙层
      mask: false
    }); */

    // 确认框
    wx.showModal({
      // 标题 7个汉字
      title: '删除提示',
      // 内容 
      content: '您真的要删除吗',
      // 是否显示取消
      showCancel: true,
      // 最多4个字
      cancelText: '考虑一下',
      cancelColor: '#000000',
      confirmText: '残忍删除',
      confirmColor: '#3CC51F',
      success: (result) => {
        if(result.confirm){
          console.log('你点击了删除了')
        }else{
          console.log('没有删除，要考虑一下')
        }
      }
    });



  },
  cfun(evt) {
    
    // 隐藏加载框
    //wx.hideLoading();

    // 隐藏提示
    //wx.hideToast();
  }
});
