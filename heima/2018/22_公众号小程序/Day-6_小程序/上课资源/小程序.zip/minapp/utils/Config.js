// 定义一常量
const domain = 'http://www.aaa.com/api/v1';

// 导出
export let Config = {
    // 用户列表
    usersUrl:`${domain}/users`
}