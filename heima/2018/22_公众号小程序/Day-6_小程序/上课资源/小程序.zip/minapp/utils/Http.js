class Http {

  /**
   * 发起网络请求
   * @param {*} param0
   */
  http_req({ url, data = {}, method = "GET" }) {
    // promise 没有把我们的函数的return丧失
    return new Promise((resolve, reject) => {
      var reqTask = wx.request({
        url,
        data,
        method: "GET",
        success: ret => {
          resolve(ret);
        },
        fail: err => {
          reject(err);
        }
      });
    });
  }
}
// 导出外部类
export default Http;