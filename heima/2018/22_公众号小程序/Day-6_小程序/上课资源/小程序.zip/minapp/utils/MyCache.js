class MyCache {
  // 设置
  set({ key, data, expire = 0 }) {
    wx.setStorageSync(key, { expire, data });
  }

  // 获取
  get(key) {
    let dt = new Date().getTime();
    let ret = wx.getStorageSync(key);
    // 永久
    if (ret.expire == 0) {
      return ret.data;
    } else {
      // 没有过有效期
      if (dt <= ret.expire) {
        return ret.data;
      } else { // 过了有效期
        wx.removeStorageSync(key);
        return null;
      }
    }
  }
}

export default MyCache;