//es6 参数  解构赋值   前期一个最终方案
export function http_req6({url = "", data = {}, scb, fcb}) {
    // 用户列表
    wx.request({
        url,
        data,
        success: ret => {
            scb(ret);
        },
        fail: () => {
            fcb("失败了");
        }
    });
}

export function http_req({url = "", data = {}}) {
    // 用户列表
    // promise 没有把我们的函数的return丧失
    return new Promise((resolve,reject) => {
        wx.request({
            url,
            data,
            success: ret => {
                resolve(ret);
            },
            fail: () => {
                reject("失败了");
            }
        });
    });
}



// A  --->  B   ---->  C
// 回调地狱
/* function a(){

    function b(){

        function c(){

        }
    }
}
 */
// Promise  es6  推荐用此方法
// es7 async await  wepy 官方提代供小程序的框架中我们可以用 

// 小程序提供的模块化
//module.exports.http_req6 = http_req6;

 
