//app.js
App({
  onLaunch () {
  }
})