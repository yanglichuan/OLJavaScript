// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    course:[
      {id:1,name:'就业课'},
      {id:2,name:'提升课'},
      {id:3,name:'免费课'},
      {id:4,name:'分类课'}
    ],
    main_index:[
      {id:1,top:'云计算大数据',center:'CTO的学前班',count:'821',money:'14980.00'},
      {id:2,top:'UI/UE设计',center:'互联网的视觉标准设计师',count:'700',money:'8800.00'},
      {id:3,top:'JavaEE',center:'一个开放的、基于标准的平台',count:'1198',money:'14980.00'},
      {id:4,top:'Python',center:'最有开发前景的开发职位',count:'845',money:'14980.00'}
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})