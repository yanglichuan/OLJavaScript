import Http from "./utils/Http.js";
let http = new Http();

App({
  onLaunch() {
    wx.getStorageSync('openid') || this._login();
  },
  _login(){
    // 登录获取code值
    wx.login({
      timeout: 10000,
      success: ret => {
        // 得到了code 有效期5分钟
        let code = ret.code;
        http.httpRequest({
          url: "http://www.aaa.com/api/v1/wxlogin",
          data: { code }
        }).then(ret=>{
          let openid = ret.data.openid;
          wx.setStorageSync('openid', openid);
        });
      }
    });
  }
});
