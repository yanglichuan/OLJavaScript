import Model from "./model.js";
let model = new Model();

Page({
  data: {
    info: {},
    msg: "",
    cdata: []
  },
  onLoad: function(options) {
    // 获取课时详情
    let p = model.getInfo(options.id, this).then(ret => {
      return model.getCommentList({ lid: this.data.info.id }).then(ret => {
        this.setData({
          cdata: ret.data.data
        });
      });
    });
  },
  // 表单提交
  postdata(evt) {
    let openid = wx.getStorageSync("openid");
    let lid = this.data.info.id;
    let info = evt.detail.value.info;

    model
      .sendComment({
        openid,
        lid,
        info
      })
      .then(ret => {
        wx.showToast({
          title: "添加评论成功",
          icon: "success",
          duration: 1500,
          mask: true
        });
        this.setData({
          msg: ""
        });
        this.data.cdata.push({
          openid,
          lid,
          info
        });
        this.setData({
          cdata: this.data.cdata
        });
      });
  }
});
