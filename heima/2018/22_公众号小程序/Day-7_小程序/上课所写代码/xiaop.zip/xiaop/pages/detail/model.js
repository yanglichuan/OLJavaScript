// 导入config文件
import { Config } from "../../utils/Config.js";
// 请求类
import Http from "../../utils/Http.js";

// 富文本插件
let WxParse = require("../../wxParse/wxParse.js");
export default class Model extends Http {
  // 获取课时详情
  getInfo(id, obj) {
    let url = Config.lesson_url + "/" + id;
    // 返回一个promise
    return this.httpRequest({ url }).then(ret => {
      // 调用富文本内容的显示
      WxParse.wxParse("ht", "html", ret.data.data.coname.intro, obj, 5);
      obj.setData({
        info: ret.data.data
      });
    });
  }

  // 获取评论列表
  // 获取列表
  getCommentList({ lid, offset = 0, limit = 20 }) {
    let url = Config.addComment + "/" + lid;
    let data = { offset, limit };
    // 返回的是一个promise
    return this.httpRequest({ url, data });
  }

  // 添加评论
  sendComment({ openid, lid, info }) {
    let url = Config.addComment;
    let data = {
      openid,
      lid,
      info
    };
    let method = "POST";
    return this.httpRequest({ url, data, method });
  }
}
