import Model from "./model.js";
let model = new Model();


Page({
  data: {
    items: [],
    offset: 0,
    limit: 2
  },

  onLoad: function(options) {
      model.getList({
        id: options.id,
        obj: this
      })
  }
});
