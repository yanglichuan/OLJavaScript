// 导入config文件
import { Config } from "../../utils/Config.js";
// 请求类
import Http from "../../utils/Http.js";

export default class Model extends Http {
  // 获取列表
  getList({ id = 0, obj }) {
    let url = Config.lesson_url;
    let data = {
      offset: obj.data.offset,
      limit: obj.data.limit,
      id
    };

    // 返回的是一个promise
    return this.httpRequest({ url, data }).then(ret => {
      obj.setData({
        items: ret.data.data,
        offset: obj.data.offset + ret.data.data.length
      });
    });
  }
}
