// 导入config文件
import { Config } from "../../utils/Config.js";
// 请求类
import Http from "../../utils/Http.js";

export default class Model extends Http {
  // 获取列表
  getList({ offset = 0, limit = 2 }) {
    wx.showLoading({
      title: "正在加载中...",
      mask: true
    });
    let url = Config.course_url;
    let data = { offset, limit };
    // 返回的是一个promise
    return this.httpRequest({ url, data });
  }
}
