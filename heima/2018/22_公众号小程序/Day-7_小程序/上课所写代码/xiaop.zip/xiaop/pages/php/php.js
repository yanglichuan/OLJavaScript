// 导入模型
import Model from "./model.js";
let model = new Model();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    offset: 0,
    limit: 2,
    course: [
      { id: 1, name: "就业课" },
      { id: 2, name: "提升课" },
      { id: 3, name: "免费课" },
      { id: 4, name: "分类课" }
    ],
    items: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getmore();
  },
  // 加载更多
  getmore() {
    model
      .getList({
        offset: this.data.offset,
        limit: this.data.limit
      })
      .then(ret => {
        wx.hideLoading();
        let len = ret.data.data.length;
        if(len <= 0){
          wx.showToast({
            title: '已经没有最新的课程了',
            icon: 'none',
            duration: 2500,
            mask: true
          });
          return;
        }
        let items = this.data.items.concat(ret.data.data);
        wx.setStorageSync('items', items);
        this.setData({
          items,
          offset: this.data.offset + len
        });
      },err=>{
        wx.hideLoading();
        let items = wx.getStorageSync('items');
        this.setData({
          items
        });
      });
  }
});
