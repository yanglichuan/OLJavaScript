// 接口域名
const domain = "http://www.aaa.com/api/v1";

// 配置
export const Config = {
  // 课程列表
  course_url: `${domain}/courses`,
  // 课时列表  播放地址
  lesson_url: `${domain}/lessons`,
  // 添加评论
  addComment:`${domain}/comments`

};
