// 请求类
class Http {
  // 发起请求 返回的是一个promise对象  解构赋值
  httpRequest({ url, data = {}, method = "GET" }) {
    return new Promise((resolve, reject) => {
      wx.request({
        url,
        data,
        method,
        success: resolve,
        fail:reject
      });
    });
  }
}

// 导出
export default Http;